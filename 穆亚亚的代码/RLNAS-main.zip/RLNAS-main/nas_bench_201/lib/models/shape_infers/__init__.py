from .InferCifarResNet_width import InferWidthCifarResNet
from .InferImagenetResNet    import InferImagenetResNet
from .InferCifarResNet_depth import InferDepthCifarResNet
from .InferCifarResNet       import InferCifarResNet
from .InferMobileNetV2       import InferMobileNetV2
