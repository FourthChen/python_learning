##################################################
# Copyright (c) Xuanyi Dong [GitHub D-X-Y], 2019 #
##################################################
from .search_model_gdas     import TinyNetworkGDAS

nas_super_nets = {'GDAS': TinyNetworkGDAS}
