#!/bin/bash
/usr/bin/python3.6 search.py