#!/bin/bash
/usr/bin/python3.5 search.py

