#!/bin/bash
/usr/bin/python3.6 test_server.py
